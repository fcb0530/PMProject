package com.example.pmproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
